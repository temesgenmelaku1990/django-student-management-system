<?php
// Starting session
session_start();
require 'index.php';
// Destroying session
session_destroy();
?>
