<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <link rel = "icon" type = "image/png" href = "images/logo.png" />
        <title>PRMS</title><style>

        </style>
    </head>

    <frameset cols="50%,*" noresize border="0" >
        <frame src="pelvis_report_final.php">
        <frame src="pelvis_scan_report.php"name="last">
    </frameset>

</html>
