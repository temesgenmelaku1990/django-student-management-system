<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <link rel = "icon" type = "image/png" href = "images/logo.png" />
        <title>PRMS</title><style>

        </style>
    </head>

    <frameset cols="50%,*" noresize border="0" >
        <frame src="form_obFirstTrimesterUSG.php">
        <frame src="OB_1st_TRIMESTER_USG_REPORT.php"name="last">
    </frameset>

</html>
