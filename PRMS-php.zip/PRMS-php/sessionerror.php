<html>
    <head>

    <link rel = "icon" type = "image/png" href = "images/logo.png" />
      <title>PRMS</title><style>
            a:link, a:visited {
                background-color: #8bf88b;
                padding: 14px 25px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                color: #424140;
            }
            #textlook{
                font-family: Comic Sans MS;
                color: #424140;
            }
            a:hover, a:active {
                 background-color: #139213;
                color: white;
            }
            #ruler{
                border-top: none;
                border-left: none;
                border-right: none;
            }
        </style>
    </head>
    <body>
        <center>
        <div style="width: 80vw">
            <br>
            <hr style="border-top: 7px solid #51bfda;   border-radius: 5px;">
            <h1 style="font-family: Comic Sans MS; color: #424140;">session expired!</h1>
            <hr style="border-bottom: 7px solid #2fcd42;   border-radius: 5px;"><br>

            <h1 id="textlook" style="background: #cad7fb; padding-top: 25px; padding-bottom: 14px; text-align: left;" >&emsp;&emsp;You are logged out due to inactivity.</h1>
            &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<a href="./" style="font-family: Comic Sans MS; border-radius: 7px; font-size: 30px; text-align: right;" >login</a>
            <br>

        </div>
                        <hr style="border-bottom: 5px solid #ddd;  padding-top: 50px; width: 95%;" id="ruler">

        </center>
    </body>
</html>
