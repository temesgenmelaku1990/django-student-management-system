<!DOCTYPE html>
<html lang="en" dir="ltr">

<link rel = "icon" type = "image/png" href = "images/logo.png" />
<title>PRMS</title>
<head>
    </head>
  <body background="../images/admin.jpg" style="background-size: 100%;background-repeat: no-repeat;">

  </body>
</html>
