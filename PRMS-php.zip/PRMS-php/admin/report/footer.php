
<div class="button_cont" >
  <input type="hidden" name="attendant" value="<?php echo $user;?>"/>

  <table>
    <tr>
      <td><a href='OB_1st_TRIMESTER_USG_REPORT.php' class='example_b print' onclick='printDiv("printableArea")'>Print</a></td>
      <td><input type="submit" name="cancel" class="example_a cancel" value="Cancel" /></td>
    </tr>
  </table>



</div>
</form>

</body>
</html>
