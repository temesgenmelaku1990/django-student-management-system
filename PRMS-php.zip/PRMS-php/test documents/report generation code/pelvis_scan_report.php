<div id="printableArea">
<?php require 'header_file.php'; ?>

<center>
  <u><h2>Pelvis Scan Report</h2></u>
  <p align="left"style="padding-left:5%;">Real time B mode ultrasonography of pelvis done.<br/>
  <u><b style="font-size:20px;">Urinary bladder</b></u><br/>
<font style="padding-left:5%;">Is normal contour. No intraluminal echoes.</font><br/>

<u><b style="font-size:20px;">Pelvis</b></u><br/>
<font style="padding-left:5%;">Trans abnorminal / Transvaginal Sonography of the pelvis done</font><br/>
<font style="padding-left:5%;">Uterus appeared antiverted / retroverted</font><br/>
<font style="padding-left:5%;">Uterus measured _________ cms</font><br/>
<font style="padding-left:5%;">Uterus appeared normal - with homogenous myometrial echoes</font><br/>
<font style="padding-left:5%;">Abnormal - with</font><br/>
<font style="padding-left:5%;">Cavity echo appeared normal / Abnormal</font><br/>
<font style="padding-left:5%;">Right Ovary measured__________cms</font><br/>
<font style="padding-left:5%;">Right Ovary appeared normal / abnormal</font><br/>
<font style="padding-left:5%;">Left Ovary measured__________cms</font><br/>
<font style="padding-left:5%;">Left Ovary appeared normal / abnormal</font><br/>
</p><br>
<table width="90%" style="border-collapse: collapse;" border="1" align="center">
  <tr>
    <td rowspan="2"align="center">Date</td>
    <td rowspan="2"align="center">Day</td>
    <td colspan="2"align="center">Dominant Follicle</td>
    <td rowspan="2"align="center">Endometrial<br/>thickness</td>
  </tr>
  <tr>
    <td align="center">Right Ovary</td>
    <td align="center">left Ovary</td>
  </tr>
  <tr>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center">.</td>
  </tr>
  <tr>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center">.</td>
  </tr>
  <tr>
    <td align="center">.</td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
  <tr>
    <td align="center">.</td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
    <td align="center"></td>
  </tr>
</table>
</p>


<p align="left"style="padding-left:5%;"><u><b style="font-size:20px;">Impression</b></u><br/><br/>_____________________________<br>_____________________________</p>


<br>
<br>
kcc<br>
<table width="100%">
  <tr>
    <td align="center"><p style="width: 90%;  bottom: 10px;  border-top: 1px solid;" align="center"><i>USG has its own limitation not all the  congenital anomalies are detected by it in the antenatal period</i></p></td>
  </tr>
</table>


</div>
<?php require 'footer.php'; ?>
