
<div id="printableArea">
<?php require 'header_file.php'; ?>

<center>
  <u><h2>OB 2/3 Trimester USG Report</h2></u>
  <p align="left"style="padding-left:5%; padding-right:5%;">Real time B mode sonography of pelvis, showed Gravid uterus with Single/<br/>
    Twin intrauterine gestation.<br/>
    Fetal Biometry (All Measurements in cms)</p>
    <table width="50%" align="center" style="border-collapse: collapse;" border="1">
      <tr>
        <td width="50%">&emsp;BPD</td>
        <td>&emsp;</td>
      </tr>
      <tr>
        <td>&emsp;HC</td>
        <td>&emsp;</td>
      </tr>
      <tr>
        <td>&emsp;AC</td>
        <td>&emsp;</td>
      </tr>
      <tr>
        <td>&emsp;FL</td>
        <td>&emsp;</td>
      </tr>
    </table>
    <table width="90%" align="center">
      <tr>
        <td width="40%">Placenta</td>
        <td>:-</td>
      </tr>
      <tr>
        <td>Liquor</td>
        <td>:-  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; AFI&emsp;:-&emsp;&emsp;&emsp;</td>
      </tr>
      <tr>
        <td>Fetal Heart Rate</td>
        <td>:-  &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;/Bpm, Rhythm Regular/</td>
      </tr>
      <tr>
        <td>Approximate fetal wt at present</td>
        <td>:- &emsp;  ffsds   &emsp;&emsp;&emsp;&emsp;gms</td>
      </tr>
      <tr>
        <td>Cardiac activity normal</td>
      </tr>
      <tr>
        <td>Fetal movements present</td>
      </tr>
      <tr>
        <td>No fetal anomalies detected</td>
      </tr>
      <tr>
        <td>Presentation Cephalic /</td>
      </tr>
      <tr>
        <td>Meternal information</td>
        <td>:- Cervical length &emsp;___________&emsp;&emsp;cms normal</td>
      </tr>
      <tr>
        <td><u><h2>IMPRESSION</h2></u></td>
      </tr>
      <tr>
        <td colspan="2">Single live intrauterine gestation corresponding to gestational age of ___ wks ___ day<br>Gestational age assigned as per LMP.</td>
      </tr>
      <tr>
        <td colspan="2"><br/><p align="center"> I, Dr.___________ declare that while conducting ultrasonography on </p>Mrs. ___________, I have neither detected not disclosed the sex of her fetus to anybody in any manner.</td>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td><br/>Dr.___________(___)<br/> consultant in ___________</td>
      </tr>

    </table>
</center>
<table width="100%">
  <tr>
    <td align="center"><p style="width: 90%;  bottom: 10px;  border-top: 1px solid;" align="center"><i>USG has its own limitation not all the  congenital anomalies are detected by it in the antenatal period</i></p></td>
  </tr>
</table>


</div>
<?php require 'footer.php'; ?>
