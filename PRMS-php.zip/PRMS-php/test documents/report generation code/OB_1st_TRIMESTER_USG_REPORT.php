<div id="printableArea">
<?php require 'header_file.php'; ?>

<center>
  <u><h2>OB First Trimester USG Report</h2></u>
  <p align="left"style="padding-left:5%;">Real time B mode ultrasonography of pelvis. Showed Gravid uterus with Single /<br/> Twin intrauterine gestation.<br/>
<table width="80%" >
  <tr>
    <td>LMP:_________</td>
    <td>GA(LMP):_________</td>
    <td>EOD(LMD):_________</td>
  </tr>
  <tr>
    <td></td>
    <td>GA(USG):_________</td>
    <td>EDD(USG):_________</td>
  </tr>
</table>
  <u><b style="font-size:20px;">Urinary bladder</b></u><br/>
<font style="padding-left:5%;">Is normal contour. No intraluminal echoes.</font><br/>

<u><b style="font-size:20px;">Uterus</b></u><br/><br/>
<font style="padding-left:5%;">Gravid uterus showing a single gestational sac containing a yolk sac and an</font><br/>
embryo of CRL _________ cms corresponding to _________ wks _________days gestational age Embryo<br/>
show regular cardiac pulsation of 144 /min.<br/><br/>
<u><b style="font-size:20px;">Ovaries</b></u><br/><br/>
Right Ovary _________ measures__________cms<br/>
left Ovary _________ measures__________cms<br/>
Both Ovaries are normal in size & echo texture<br/>
no free fluid.</font>
</p>
<p align="left"style="padding-left:5%;"><u><b style="font-size:20px;">Impression</b></u><br/><br/><font style="padding-Left:4%;">Single live intra uterine gestation corresponding to gestational age of _________wks</font><br>_________day Gestational age assigned as per LMP.</p>
<p align="left"style="padding-left:5%;"><font style="padding-Left:4%;">I, Dr._________ declare that which conducting ultrasonography on </font><br/>Mrs.____________________________. I have neither detected not disclosed the sac of her fetus<br/>to anybody in any manner.</p>
<br>

<table width="100%">
  <tr>
    <td align="center"><p style="width: 90%;  bottom: 10px;  border-top: 1px solid;" align="center"><i>USG has its own limitation not all the  congenital anomalies are detected by it in the antenatal period</i></p></td>
  </tr>
</table>
</center>


</div>
<?php require 'footer.php'; ?>
